from .droppedKey import DroppedKey


class FaceKey(DroppedKey):
    def __init__(self):
        super().__init__(0x27F)
