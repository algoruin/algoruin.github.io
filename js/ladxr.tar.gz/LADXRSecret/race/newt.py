from roomEditor import RoomEditor
from assembler import ASM
import random
import utils


def prePatch(rom):
    pass

def postPatch(rom):
    rom.patch(0x01, 0x1F36, ASM("ld [hl], $00"), "", fill_nop=True)  # Don't disable SRAM ever
    rom.patch(0x01, 0x1F3A, ASM("ld [hl], $FF"), "", fill_nop=True)  # Don't disable SRAM ever

    rom.patch(0x01, 0x0383, ASM("dw $0F48"), ASM("dw $7E78"), fill_nop=True)
    rom.patch(0x01, 0x3E78, "00" * (0x190-8), ASM("""
    ld  a, [$DBA5] ; wIsIndoor
    and a
    jp  nz, indoor 

    ld   a, [$B002] ; minute
    and  1
    jr   z, dayTime
    ld   a, [$B001] ; seconds
    cp   $10
    jr   c, duskTime
    jr   nightTime

dayTime:
    call setLight
    ; Don't do random spawns the first minute.
    ld   a, [$B002] ; minute
    and  a
    jp   z, $0F48
    ; Random daytime spawn
    call $280D ; GetRandomByte
    and  a
    call z, spawn
    jp $0F48

duskTime:
    call setDarkness
    jp $0F48

nightTime:
    call setDarkness
    ldh  a, [$FFE7]
    and  7
    call z, spawn
    jp $0F48

spawn:
    ld   a, $6C ; ENTITY_CUCCO 
    ld   e, $07
    call $3B98 ; SpawnNewEntityInRange_trampoline  
    ret  c

    ld   a, $13 ; WAVE_SFX_CUCCO_HURT 
    ldh  [$FFF3], a ; hWaveSfx 
    ld   hl, $C290 ; wEntitiesStateTable 
    add  hl, de
    ld   [hl], $03
    ld   hl, $C310 ; wEntitiesPosZTable  
    add  hl, de
    ld   [hl], $10
    ld   hl, $C340 ; wEntitiesPhysicsFlagsTable 
    add  hl, de
    ld   [hl], $12 ; 2 | ENTITY_PHYSICS_SHADOW
    ld   hl, $C350 ; wEntitiesHitboxFlagsTable  
    add  hl, de
    ld   [hl], $80
    ld   hl, $C430 ; wEntitiesOptions1Table 
    add  hl, de
    ld   [hl], $40 ; ENTITY_OPT1_SWORD_CLINK_OFF 
    call $280D ; GetRandomByte
    and  $0F
    ld   c, a
    ld   hl, Data_005_468F
    add  hl, bc
    ld   a, [hl]
    ld   hl, $C200 ; wEntitiesPosXTable
    add  hl, de
    ld   [hl], a
    ld   hl, Data_005_469F
    add  hl, bc
    ld   a, [hl]
    ld   hl, $C210 ; wEntitiesPosYTable  
    add  hl, de
    ld   [hl], a
    ld   c, e
    ld   b, d
    ld   a, $18
    call $3BAA ; ApplyVectorTowardsLink_trampoline  
    ret

setDarkness:
    ld  a, [$C107]
    and a
    ret nz
    
    ld  a, $01
    ld  [$C107], a
    ld  a, [$DDD1] ;wPaletteDataFlags
    or  3
    ld  [$DDD1], a
    ret

setLight:
    ld  a, [$C107]
    and a
    ret z
    
    xor a
    ld  [$C107], a
    ld  a, [$DDD1] ;wPaletteDataFlags
    or  3
    ld  [$DDD1], a
    ret

indoor:
    ldh  a, [$FFF7] ; hMapId
    cp   8
    jp   nc, $0F48 

    ld   a, [$B002] ; minute
    and  1
    jr   z, dayTimeIndoor
    ld   a, [$B001] ; seconds
    cp   $30
    jr   c, dayTimeIndoor
    cp   $40
    jr   c, duskTimeIndoor
    jr   nightTimeIndoor

dayTimeIndoor:
    call setLight
    jp $0F48

duskTimeIndoor:
    call setDarkness
    jp $0F48

nightTimeIndoor:
    call setDarkness
    ldh  a, [$FFE7]
    and  a
    call z, spawnIndoor
    jp $0F48

spawnIndoor:
    ld   a, $1B
    ld   e, $08
    call $3B98 ; SpawnNewEntity in range
    ret  c

    ld   hl, $C310
    add  hl, de
    ld   [hl], $7F

    ; Place somewhere random
    ld   hl, $C200
    add  hl, de
    call $280D ; random number
    and  $7F
    add  a, $08
    ld   [hl], a
    ld   hl, $C210
    add  hl, de
    call $280D ; random number
    and  $3F
    add  a, $20
    ld   [hl], a

    ret


Data_005_468F:
    db   $28, $48, $68, $88, $18, $38, $58, $78, $00, $00, $00, $00, $A0, $A0, $A0, $A0

Data_005_469F:
    db   $00, $00, $00, $00, $90, $90, $90, $90, $20, $40, $60, $80, $20, $40, $60, $80

    """, 0x7E78), fill_nop=True)

    rom.patch(0x21, 0x0013, ASM("call $4062"), ASM("call $7F00"))
    rom.patch(0x21, 0x0023, ASM("call $4062"), ASM("call $7F00"))
    rom.patch(0x21, 0x3F00, "00" * 0x100, ASM("""
    ld  a, [$C107]
    and a
    jp  z, $4062
    
    ; Custom code to darken all colors
    ld   b, $20
    ld   a, $80
    ld   [de], a
    inc  de
loop:
    ; Wait STAT
        ldh  a, [$FF41]
        and  $02
        jr   nz, $FA
    ld   a, [hl+]
    ld   c, [hl]
    inc  hl
    srl  c
    rra
    and  $EF
    ld   [de], a
    ld   a, c
    and  $3D
    ld   [de], a
    dec  b
    jr   nz, loop
    ret
    """), fill_nop=True)
