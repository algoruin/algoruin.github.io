
from roomEditor import RoomEditor
from assembler import ASM
import random
import utils


def prePatch(rom):
    pass

def postPatch(rom):
    rom.patch(0x01, 0x1F36, ASM("ld [hl], $00"), "", fill_nop=True)  # Don't disable SRAM ever
    rom.patch(0x01, 0x1F3A, ASM("ld [hl], $FF"), "", fill_nop=True)  # Don't disable SRAM ever

    rom.patch(0x01, 0x0383, ASM("dw $0F48"), ASM("dw $7E80"), fill_nop=True)
    rom.patch(0x01, 0x3E80, "00" * 0x180, ASM("""
Y_OFFSET := 4
#MACRO WAIT_STAT
    ldh  a, [$FF41]
    and  $02
    jr   nz, $FA
#END

    ldh  a, [$FF98] ; link X
    swap a
    and  $0F
    ld   b, a
    ldh  a, [$FF99] ; link Y
    sub  Y_OFFSET
    swap a
    and  $0F
    ld   c, a

    ld   a, [$C124] ; room transition state
    and  a
    jr   nz, skipChangeCheck
    ld   a, [$DB96] ; gameplay subtype
    cp   7
    jr   nz, skipChangeCheck
    ld   a, [$C11C] ; motion state
    cp   2
    jr   nc, skipChangeCheck

    ldh  a, [$FF80]
    cp   b
    jr   nz, changed
    ldh  a, [$FF81]
    cp   c
    jr   nz, changed

skipChangeCheck:
    ld   hl, $FF80
    ld   [hl], b
    inc  hl
    ld   [hl], c
    jp   $0F48

changed:
    ld   a, [$DBB1] ; wLinkMapEntryPositionX
    swap a
    and  $0F
    ld   hl, $FF80
    cp   [hl]
    jr   nz, notEnterPos
    ld   a, [$DBB2] ; wLinkMapEntryPositionY
    sub  Y_OFFSET
    swap a
    and  $0F
    inc  hl
    cp   [hl]
    jr   z, skipChangeCheck

notEnterPos:
    ldh  a, [$FFF9] ; hIsSideScroll
    and  a
    jr   nz, skipChangeCheck

    call getRoomObjectAddr
    ld   d, [hl]
    ld   hl, noChangeListOutdoor
    ld   a, [$DBA5]
    and  a
    jr   z, .notindoor
    ld   hl, noChangeListIndoor
.notindoor:
checkNoChangeListLoop:
    ld   a, [hl+]
    cp   d
    jr   z, skipChangeCheck
    inc  a
    jr   nz, checkNoChangeListLoop

    ldh  a, [$FF80]
    swap a
    ldh  [$FFCE], a

    ldh  a, [$FF81]
    swap a
    ldh  [$FFCD], a
    call $2887 ; convert X/Y position to VRAM address

    ld   a, [$DBA5]
    and  a
    jr   nz, indoor
    
    push hl
    WAIT_STAT
    ld   a, $68
    ld   [hl+], a
    inc  a
    ld   [hl+], a
    ld   de, 32 - 2
    add  hl, de
    WAIT_STAT
    ld   a, $78
    ld   [hl+], a
    inc  a
    ld   [hl+], a
    pop  hl
    
    ld   a, 1
    ldh  [$FF4F], a ;VBK

    WAIT_STAT
    ld   a, $03
    ld   [hl+], a
    ld   [hl+], a
    ld   de, 32 - 2
    add  hl, de
    WAIT_STAT
    ld   a, $03
    ld   [hl+], a
    ld   [hl+], a
    
    xor  a
    ldh  [$FF4F], a ;VBK
    
    call getRoomObjectAddr
    ld   a, $E8
    ld   [hl], a
    push bc
    ld   a, $81
    call $0B2F
    pop  bc

    jp   skipChangeCheck

indoor:    
    push hl
    WAIT_STAT
    ld   a, $7E
    ld   [hl+], a
    ld   [hl+], a
    ld   de, 32 - 2
    add  hl, de
    WAIT_STAT
    ld   a, $7E
    ld   [hl+], a
    ld   [hl+], a
    pop  hl
    
    ld   a, 1
    ldh  [$FF4F], a ;VBK

    WAIT_STAT
    ld   a, $04
    ld   [hl+], a
    ld   [hl+], a
    ld   de, 32 - 2
    add  hl, de
    WAIT_STAT
    ld   a, $04
    ld   [hl+], a
    ld   [hl+], a
    ld   a, 1
    
    xor  a
    ldh  [$FF4F], a ;VBK
    
    call getRoomObjectAddr
    ld   a, $01
    ld   [hl], a
    
    jp   skipChangeCheck

getRoomObjectAddr:
    ld   hl, $D711 ; wRoomObjects
    ldh  a, [$FF80]
    add  a, l
    ld   l, a
    ldh  a, [$FF81]
    swap a
    add  a, l
    ld   l, a
    ret

noChangeListOutdoor:
    db   $E1, $E2, $E3, $C6,  $FF
noChangeListIndoor:
    db   $BB, $BC, $8C, $08, $0C, $0B, $09, $0A, $44, $43, $BE, $CB, $A8,  $FF
    """, 0x7E80), fill_nop=True)
